# instagram-downloader-php
A simple instagram post / media downloader written in PHP.

# Usage
Enter Instagram Profile/post On Index.php

# Source
This script uses open source projects to work properly:
 - [jQuery](https://jquery.com/)
 - [Twitter Bootstrap](https://getbootstrap.com/)
 - [PHP](http://php.net/)

# Requirements
This script requires the following installed:
 - PHP
 - cURL
 
 # License

instagram-downloader-php is licensed under the [MIT license](LICENSE), see [LICENSE.md](LICENSE) for details.
